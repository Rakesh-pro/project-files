def average(num1, num2):
    return (num1 + num2) / 2

avg = average(2, 8)
print(avg)