def packer(**kwargs, name = None):
    print(kwargs)



def unpacker(first_name = None, last_name = None):
    if first_name and last_name:
        print("Hi {} {}!".format(first_name, last_name))
    else:
        print("hi no name")

unpacker(**{"last_name": "Akbarzadeh", "first_name": "sepehr"})

packer(name = "sepehr", num = 42, nationality = "IRAN")