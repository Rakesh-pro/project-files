def add(base, *args):
    total = base
    for num in args:
        total += num
    return total

print(add(5, 20))

def add(base, multiply = "", *args, **kwargs):