from PIL import Image
from PIL import ImageEnhance, ImageFilter


var = Image.open('mountain.jpg')

box = (200, 200, 600, 300)

var_enhancer = ImageEnhance.Color(var)
var_enhancer.enhance(0.2).show()

var.filter(ImageFilter.GaussianBlur(radius = 10)).show()