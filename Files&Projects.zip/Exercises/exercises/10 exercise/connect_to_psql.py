import sqlalchemy
from sqlalchemy import create_engine

#db_connstring = 'postgresql+psycopg2://user:password@localhost:port/dbname'
db_connstring = 'postgresql+psycopg2://paravid:1234@localhost:4321/paravid'

engine = create_engine(db_connstring, echo = True)

engine.execute("select 1").scalar()