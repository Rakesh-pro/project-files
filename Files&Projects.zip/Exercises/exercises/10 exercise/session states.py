# State session
### Transient
### Pending
### Persistent
### Detach

## Rollback
#fake_user = User('fakeuser', 'invalid', '1234')
#session.add(fake_user)
#print(fake_user in session)
#session.rollback()
#print(fake_user in session)