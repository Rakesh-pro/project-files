class Protected:
    __name = "security"

    def __method(self):
        return self.__name


