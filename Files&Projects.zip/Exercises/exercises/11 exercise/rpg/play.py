

from thieves import Thief


sepehr = Thief(name = "sepehr", sneaky = False)


print(sepehr.sneaky)
print(sepehr.agile)
print(sepehr.hide(8))